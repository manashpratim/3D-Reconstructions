"""
Homework4.
Replace 'pass' by your implementation.
"""

# Insert your package here


'''
Q2.1: Eight Point Algorithm
    Input:  pts1, Nx2 Matrix
            pts2, Nx2 Matrix
            M, a scalar parameter computed as max (imwidth, imheight)
    Output: F, the fundamental matrix
'''
import numpy as np
import helper
from scipy.optimize import least_squares
from helper import *

def eightpoint(pts1, pts2, M):
        # Replace pass by your implementation
        
        x1 = pts1/M
        x2 = pts2/M

        xl = x1[:,0]
        yl = x1[:,1]
        xr = x2[:,0]
        yr = x2[:,1]

        A = np.array([xl*xr,xl*yr,xl,yl*xr,yl*yr,yl,xr,yr,np.ones(xl.shape)]).T

        _,_,V = np.linalg.svd(A, full_matrices=False)
        #w,v = np.linalg.eig(np.dot(A,A.T))
        #F= v[:,np.argmin((abs(w)))].reshape(3,3)

        F = V[-1,:].reshape(3,3)
        u,s,v =  np.linalg.svd(F, full_matrices=False)
        s_new = np.diag(s)
        s_new[-1,-1] = 0

        F = u @ s_new @ v

        T = np.array([[1/M,0,0],[0,1/M,0],[0, 0 ,1]])
        #F = T.T*F*T
        F = np.matmul(np.matmul(T.T,F),T)
        F = helper.refineF(F, pts1, pts2)

        return F
    


'''
Q2.2: Seven Point Algorithm
    Input:  pts1, Nx2 Matrix
            pts2, Nx2 Matrix
            M, a scalar parameter computed as max (imwidth, imheight)
    Output: Farray, a list of estimated fundamental matrix.
'''
def sevenpoint(pts1, pts2, M):
    # Replace pass by your implementation
    pass


'''
Q3.1: Compute the essential matrix E.
    Input:  F, fundamental matrix
            K1, internal camera calibration matrix of camera 1
            K2, internal camera calibration matrix of camera 2
    Output: E, the essential matrix
'''
def essentialMatrix(F, K1, K2):
    # Replace pass by your implementation
    E = np.dot(np.dot(K1.T,F),K2)
    return E


'''
Q3.2: Triangulate a set of 2D coordinates in the image to a set of 3D points.
    Input:  C1, the 3x4 camera matrix
            pts1, the Nx2 matrix with the 2D image coordinates per row
            C2, the 3x4 camera matrix
            pts2, the Nx2 matrix with the 2D image coordinates per row
    Output: P, the Nx3 matrix with the corresponding 3D points per row
            err, the reprojection error.
'''
def triangulate(C1, pts1, C2, pts2):
    # Replace pass by your implementation
    P = np.zeros((pts1.shape[0],3))
    
    for i in range(pts1.shape[0]):
        A = np.zeros((4,4))
        A[0,:] = np.array(pts1[i,0]*C1[2,:] - C1[0,:])
        A[1,:] = np.array(pts1[i,1]*C1[2,:] - C1[1,:])
        A[2,:] = np.array(pts2[i,0]*C2[2,:] - C2[0,:])
        A[3,:] = np.array(pts2[i,1]*C2[2,:] - C2[1,:])
        _,_,v = np.linalg.svd(A, full_matrices=False)
        P[i,:] = (v[-1,:]/v[-1,-1])[:3]

    p = np.array(list(P.T) + list(np.ones((pts1.shape[0],1)).T))
    p1 = np.dot(C1,p)
    p1 = (p1/p1[-1]).T[:,:2]
    p2 = np.dot(C2,p)
    p2 = (p2/p2[-1]).T[:,:2]
    error = np.sum((p1 - pts1)**2 + (p2-pts2)**2)
    return P,error

'''
Q4.1: 3D visualization of the temple images.
    Input:  im1, the first image
            im2, the second image
            F, the fundamental matrix
            x1, x-coordinates of a pixel on im1
            y1, y-coordinates of a pixel on im1
    Output: x2, x-coordinates of the pixel on im2
            y2, y-coordinates of the pixel on im2

'''
def gaussianfilter(shape,sigma):

    m = shape[0]//2
    n = shape[1]//2
    
    y = np.arange(-m,m+1, 1).reshape(-1,1)
    x = np.arange(-n,n+1, 1).reshape(1,-1)
    h = np.exp(-(np.square(x) + np.square(y)) / (2.*np.square(sigma)))
    h[ h < np.finfo(h.dtype).eps*h.max() ] = 0
    sumh = sum(sum(h))
    if sumh != 0:
        h = h/sumh
    return h


def epipolarCorrespondence(im1, im2, F, x1, y1):
    # Replace pass by your implementation
    #pass
    window = 10
    sigma = 3
    minimum =1000000
    epline = np.matmul(F,np.array([x1,y1,1]))

    gaussian = gaussianfilter((window,window),sigma)
    filt = np.zeros((gaussian.shape[0],gaussian.shape[1],3))
    filt[:,:,0] = gaussian 
    filt[:,:,1] = gaussian 
    filt[:,:,2] = gaussian 
    patch1 = im1[y1-(window//2):y1+(window//2)+1,x1-(window//2):x1+(window//2)+1]

    for i in range(im2.shape[0]):
        x2 = int(round((-epline[1]*i -epline[2])/epline[0]))
        dist = np.square(x2 - x1) + np.square(i - y1)
        
        if x2-window >= 0 and x2 +window< im2.shape[1] and i-window>=0 and i+window<im2.shape[0] and dist<200:
            patch2 = im2[i-(window//2):i+(window//2)+1,x2-(window//2):x2+(window//2)+1]
            
            dis = patch1 - patch2
            weightdis = filt*dis
            error = np.linalg.norm(weightdis)

            if error < minimum:                
                minimum = error
                x21 = x2
                y2 = i

    return x21,y2



'''
Q5.1: RANSAC method.
    Input:  pts1, Nx2 Matrix
            pts2, Nx2 Matrix
            M, a scaler parameter
    Output: F, the fundamental matrix
            inliers, Nx1 bool vector set to true for inliers
'''
def ransacF(pts1, pts2, M, nIters=50, tol=5):
    # Replace pass by your implementation
    maximum = 0
    for i in range(nIters):
        d =  np.zeros((pts1.shape[0]))
        ind = np.random.choice(pts1.shape[0],8)
        rnd1 = pts1[ind]
        rnd2 = pts2[ind]
        f = eightpoint(rnd1, rnd2, M)
        
        for i in range(pts1.shape[0]):
            epline = np.matmul(f,np.array([pts1[i][0],pts1[i][1],1]))
            
            x2 = int(round((-epline[1]*pts2[i][1] - epline[2])/epline[0]))
            d[i] = np.square(x2 - pts2[i][0])
            #print(dist)
            
            
        inline = d<tol
        if sum(inline)>maximum:
            F=f
            maximum  = sum(inline)
            inliers = inline
    
    return F,inliers

'''
Q5.2: Rodrigues formula.
    Input:  r, a 3x1 vector
    Output: R, a rotation matrix
'''
def rodrigues(r):
    # Replace pass by your implementation
    theta = np.linalg.norm(r)
    u = r/theta
    ux = np.array([[0,-u[2][0],u[1][0]],[u[2][0],0,-u[0][0]],[-u[1][0],u[0][0],0]])
    R = np.eye(3)*np.cos(theta) + (1-np.cos(theta))*np.dot(u,u.T) + ux*np.sin(theta)
    return R

'''
Q5.2: Inverse Rodrigues formula.
    Input:  R, a rotation matrix
    Output: r, a 3x1 vector
'''
def invRodrigues(R):
    # Replace pass by your implementation

    r = np.array([[R[2, 1] - R[1, 2]], [R[0, 2] - R[2, 0]], [R[1, 0] - R[0, 1]]])
    s = np.sqrt((r[0]*r[0] + r[1]*r[1] + r[2]*r[2])*0.25)[0]
    c = (np.trace(R)-1)*0.5

    c = 1 if c>1 else -1 if c<-1 else c
    theta = np.arccos(c)

    if s < 1e-5:
        if c > 0:
            r = np.zeros((3,1))
        else:

            t = (R[0, 0] + 1)*0.5
            r[0] = np.sqrt(np.maximum(t,0.))
            t = (R[1, 1] + 1)*0.5
            r[1] = np.sqrt(np.maximum(t,0.))*(-1 if R[0, 1] < 0 else 1.)
            t = (R[2, 2] + 1)*0.5
            r[2] = np.sqrt(np.maximum(t,0.))*(-1 if R[0, 2] < 0 else 1.)
            if np.abs(r[0]) < np.abs(r[1]) and np.abs(r[0]) < np.abs(r[2]) and (R[1, 2] > 0) != (r[1]*r[2] > 0):
                r[2] = -r[2]
            theta = theta/np.linalg.norm(r)
            r = r*theta
    else:
        vth = 1/(2*s)
        vth = vth*theta
        r = r*vth
    return r
    

'''
Q5.3: Rodrigues residual.
    Input:  K1, the intrinsics of camera 1
            M1, the extrinsics of camera 1
            p1, the 2D coordinates of points in image 1
            K2, the intrinsics of camera 2
            p2, the 2D coordinates of points in image 2
            x, the flattened concatenationg of P, r2, and t2.
    Output: residuals, 4N x 1 vector, the difference between original and estimated projections
'''
def rodriguesResidual(K1, M1, p1, K2, p2,x):
    # Replace pass by your implementation
    #pass
    P = x[:-6].reshape(-1,3)
    r2 = x[-6:-3].reshape(-1,1)
    t2 = x[-3:].reshape(-1,1)
    M2 = np.hstack((rodrigues(r2),t2))
    C1 = np.dot(K1,M1)
    C2 = np.dot(K2,M2)
    p = np.array(list(P.T) + list(np.ones((p1.shape[0],1)).T))
    p1_hat = np.dot(C1,p)
    p1_hat = (p1_hat/p1_hat[-1]).T[:,:2]
    p2_hat = np.dot(C2,p)
    p2_hat = (p2_hat/p2_hat[-1]).T[:,:2]
    
    return np.concatenate([(p1 - p1_hat).reshape([-1]),(p2 - p2_hat).reshape([-1])]).reshape(-1,1)

'''
Q5.3 Bundle adjustment.
    Input:  K1, the intrinsics of camera 1
            M1, the extrinsics of camera 1
            p1, the 2D coordinates of points in image 1
            K2,  the intrinsics of camera 2
            M2_init, the initial extrinsics of camera 1
            p2, the 2D coordinates of points in image 2
            P_init, the initial 3D coordinates of points
    Output: M2, the optimized extrinsics of camera 1
            P2, the optimized 3D coordinates of points
'''
def bundleAdjustment(K1, M1, p1, K2, M2_init, p2, P_init):
    # Replace pass by your implementation
    t2 = M2_init[:,-1].reshape(-1,1)
    r2 = invRodrigues(M2_init[:,:-1])

    x0 = np.concatenate([P_init.flatten(),r2.flatten(),t2.flatten()])
    def temp(x0):
         return rodriguesResidual(K1, M1, p1, K2, p2,x0).flatten()
    
    res = least_squares(temp, x0, loss='soft_l1')

    P2 =  res['x'][:-6].reshape(-1,3)
    r22 = res['x'][-6:-3].reshape(-1,1)
    t22 = res['x'][-3:].reshape(-1,1)
    M2 = np.hstack((rodrigues(r22),t22))

    return M2,P2

    #pass
'''
Q6.1 Multi-View Reconstruction of keypoints.
    Input:  C1, the 3x4 camera matrix
            pts1, the Nx3 matrix with the 2D image coordinates and confidence per row
            C2, the 3x4 camera matrix
            pts2, the Nx3 matrix with the 2D image coordinates and confidence per row
            C3, the 3x4 camera matrix
            pts3, the Nx3 matrix with the 2D image coordinates and confidence per row
    Output: P, the Nx3 matrix with the corresponding 3D points for each keypoint per row
            err, the reprojection error.
'''
def MultiviewReconstruction(C1, pts1, C2, pts2, C3, pts3, Thres):
    # Replace pass by your implementation
    pass
    P = np.zeros((pts1.shape[0],3))
    
    for i in range(pts1.shape[0]):
        A = np.zeros((6,4))
        A[0,:] = np.array(pts1[i,0]*C1[2,:] - C1[0,:])
        A[1,:] = np.array(pts1[i,1]*C1[2,:] - C1[1,:])
        A[2,:] = np.array(pts2[i,0]*C2[2,:] - C2[0,:])
        A[3,:] = np.array(pts2[i,1]*C2[2,:] - C2[1,:])
        A[4,:] = np.array(pts3[i,0]*C3[2,:] - C3[0,:])
        A[5,:] = np.array(pts3[i,1]*C3[2,:] - C3[1,:])
        _,_,v = np.linalg.svd(A, full_matrices=False)
        P[i,:] = (v[-1,:]/v[-1,-1])[:3]

    p = np.array(list(P.T) + list(np.ones((pts1.shape[0],1)).T))
    p1 = np.dot(C1,p)
    p1 = (p1/p1[-1]).T[:,:2]
    p2 = np.dot(C2,p)
    p2 = (p2/p2[-1]).T[:,:2]
    p3 = np.dot(C3,p)
    p3 = (p3/p3[-1]).T[:,:2]
    error = np.sum((p1 - pts1[:,:-1])**2 + (p2 - pts2[:,:-1])**2 + (p3 - pts3[:,:-1])**2)
    return P,error
