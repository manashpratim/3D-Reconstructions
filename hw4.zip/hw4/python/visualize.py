'''
Q4.2:
    1. Integrating everything together.
    2. Loads necessary files from ../data/ and visualizes 3D reconstruction using scatter
'''
import numpy as np
from PIL import Image
from helper import *
from submission import *
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
from mpl_toolkits.mplot3d import Axes3D

data = np.load('../data/some_corresp.npz')
data1 = np.load('../data/templeCoords.npz')
img1 = np.array(Image.open('../data/im1.png'))
img2 = np.array(Image.open('../data/im2.png'))
intrinsics = np.load('../data/intrinsics.npz')
data3 = np.load('../data/some_corresp_noisy.npz')
n1 = data3['pts1']
n2 = data3['pts2']

pts1 = data['pts1']
pts2 = data['pts2']
M = max(img1.shape)

K1 = intrinsics['K1']
K2 = intrinsics['K2']

x1 = data1['x1']
y1 = data1['y1']

F = eightpoint(pts1, pts2, M)
#F,_ =ransacF(n1, n2, M, 50, 50)

E = essentialMatrix(F, K1, K2)

pts11 = np.hstack((x1,y1))
pts22 = np.zeros((x1.shape[0],2))

for i in range(x1.shape[0]):
    pt1 = x1[i][0]
    pt2 = y1[i][0]
    pts22[i][0],pts22[i][1] = epipolarCorrespondence(img1, img2, F, pt1, pt2)



M2s = camera2(E)

M1 = np.hstack((np.identity(3), np.array([[0],[0],[0]])))

C1 = np.dot(K1,M1)

for i in range(M2s.shape[-1]):
    C2 = np.dot(K2,M2s[:,:,i])
    P,_ = triangulate(C1, pts11, C2, pts22)
    if all(P[:,2]>0):
    	M2 = M2s[:,:,i]
    	break

fig = plt.figure()
ax = Axes3D(fig)
ax.scatter(P[:,0], P[:,1],P[:,2])
plt.show()

#np.savez('q2_1.npz', F=F, M=M) 
np.savez('q4_1.npz', F=F, pts1=pts1, pts2=pts2)   
np.savez('q4_2.npz', F=F, M1=M1, M2=M2, C1=C1, C2=C2)
	