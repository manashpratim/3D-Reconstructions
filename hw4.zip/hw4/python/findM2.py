'''
Q3.3:
    1. Load point correspondences
    2. Obtain the correct M2
    3. Save the correct M2, C2, and P to q3_3.npz
'''

import numpy as np
from PIL import Image
from helper import *
from submission import *

data = np.load('../data/some_corresp.npz')
img1 = np.array(Image.open('../data/im1.png'))
img2 = np.array(Image.open('../data/im2.png'))
intrinsics = np.load('../data/intrinsics.npz')

pts1 = data['pts1']
pts2 = data['pts2']
M = max(img1.shape)

K1 = intrinsics['K1']
K2 = intrinsics['K2']

F = eightpoint(pts1, pts2, M)

E = essentialMatrix(F, K1, K2)

M2s = camera2(E)

C1 = np.dot(K1,np.hstack((np.identity(3), np.array([[0],[0],[0]]))))

for i in range(M2s.shape[-1]):
    C2 = np.dot(K2,M2s[:,:,i])
    P,_ = triangulate(C1, pts1, C2, pts2)
    if all(P[:,2]>0):
    	M2 = M2s[:,:,i]
    	break

np.savez('q2_1.npz', F=F, M=M)    
np.savez('q3_3.npz', M2=M2, C2=C2,P=P)

