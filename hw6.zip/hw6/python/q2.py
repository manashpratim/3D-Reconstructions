# ##################################################################### #
# 16720: Computer Vision Homework 6
# Carnegie Mellon University
# April 20, 2020
# ##################################################################### #

import numpy as np
from q1 import loadData, estimateAlbedosNormals, displayAlbedosNormals
from q1 import estimateShape, plotSurface 
from utils import enforceIntegrability

def estimatePseudonormalsUncalibrated(I):

    """
    Question 2 (b)

    Estimate pseudonormals without the help of light source directions. 

    Parameters
    ----------
    I : numpy.ndarray
        The 7 x P matrix of loaded images

    Returns
    -------
    B : numpy.ndarray
        The 3 x P matrix of pesudonormals

    """

    B = None
    L = None

    u,s,v = np.linalg.svd(I, full_matrices=False)
    s[3:] = 0
    W = np.diag(s)[:3,:3]
    W = np.sqrt(W)
    V = v[:3,:]
    U = u[:,:3]
    L = np.dot(U,W)
    B = np.dot(W,V)


    return B, L


if __name__ == "__main__":

    # Put your main code here
    #pass
    I,L,s = loadData(path = "../data/")
    B, L1 = estimatePseudonormalsUncalibrated(I)
    albedos,normals = estimateAlbedosNormals(B)
    albedoIm,normalIm = displayAlbedosNormals(albedos, normals, s)
    normals = enforceIntegrability(B, s, sig = 3)
    surface = estimateShape(normals, s)
    plotSurface(surface)
