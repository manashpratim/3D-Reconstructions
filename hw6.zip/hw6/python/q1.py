# ##################################################################### #
# 16720: Computer Vision Homework 6
# Carnegie Mellon University
# April 20, 2020
# ##################################################################### #

# Imports
import numpy as np
from matplotlib import pyplot as plt
from utils import integrateFrankot
import skimage
from mpl_toolkits import mplot3d

def renderNDotLSphere(center, rad, light, pxSize, res):

    """
    Question 1 (b)

    Render a sphere with a given center and radius. The camera is 
    orthographic and looks towards the sphere in the negative z
    direction. The camera's sensor axes are centerd on and aligned
    with the x- and y-axes.

    Parameters
    ----------
    center : numpy.ndarray
        The center of the hemispherical bowl in an array of size (3,)

    rad : float
        The radius of the bowl

    light : numpy.ndarray
        The direction of incoming light

    pxSize : float
        Pixel size

    res : numpy.ndarray
        The resolution of the camera frame

    Returns
    -------
    image : numpy.ndarray
        The rendered image of the hemispherical bowl

    """
    rad = rad*10000  
    y_range = (res[1]*pxSize)//2
    x_range = (res[0]*pxSize)//2

    x1= pxSize//2
    x2 = x_range - (pxSize//2)
    y1= pxSize//2
    y2 = y_range - (pxSize//2)

    xpos = []
    for i in range(x1,x2,pxSize):
	    xpos.append(i)
    xpos = [i+0.5 for i in xpos]
    xneg = [-i for i in xpos]

    ypos = []
    for i in range(y1,y2,pxSize):
	    ypos.append(i)
    ypos = [i+0.5 for i in ypos]
    yneg = [-i for i in ypos]
    y = ypos[::-1] + yneg
    x = xpos[::-1] + xneg

    image = None
    l1 = light.reshape(1,-1)

    def normalize(v):
	    den = np.sqrt(np.square(v[0]) + np.square(v[1]) + np.square(v[2]))
	    return np.array([v[0]/den, v[1]/den, v[2]/den]).reshape(-1,1)
	 
    image = np.zeros((res[1],res[0]))
    for i in range(image.shape[0]):
	    for j in range(image.shape[1]):
	        if np.square(x[j]) + np.square(y[i]) <= np.square(rad):
	            vec = normalize((x[j],y[i],np.sqrt(rad*rad - x[j]*x[j] - y[i]*y[i])))
	            b = np.dot(l1,vec)
	            b = 0 if b<0 else b
	            image[i][j] = b

    plt.figure(num=None, figsize=(20, 5), dpi=80)
    plt.imshow(image)
    plt.savefig('sphere1.png')
    plt.show()

    return image


def loadData(path = "../data/"):

    """
    Question 1 (c)

    Load data from the path given. The images are stored as input_n.tif
    for n = {1...7}. The source lighting directions are stored in
    sources.mat.

    Paramters
    ---------
    path: str
        Path of the data directory

    Returns
    -------
    I : numpy.ndarray
        The 7 x P matrix of vectorized images

    L : numpy.ndarray
        The 3 x 7 matrix of lighting directions

    s: tuple
        Image shape

    """

    I = None
    L = None
    s = None

    img = []
    for i in range(7):
	    img.append(skimage.io.imread(path+'input_'+str(i+1)+'.tif', plugin='tifffile'))
    img = np.array(img)
    s = img[0,:,:,0].shape
    L = np.load(path+'sources.npy')
    I = []
    for i in range(img.shape[0]):
	    I = I + list(skimage.color.rgb2xyz(img[i])[:,:,1].flatten().reshape(1,-1)) 
    L = np.load('../data/sources.npy')
    I = np.array(I)

    return I, L, s


def estimatePseudonormalsCalibrated(I, L):

    """
    Question 1 (e)

    In calibrated photometric stereo, estimate pseudonormals from the
    light direction and image matrices

    Parameters
    ----------
    I : numpy.ndarray
        The 7 x P array of vectorized images

    L : numpy.ndarray
        The 3 x 7 array of lighting directions

    Returns
    -------
    B : numpy.ndarray
        The 3 x P matrix of pesudonormals
    """

    B = None
    B = np.linalg.lstsq(L,I)[0]
    return B


def estimateAlbedosNormals(B):

    '''
    Question 1 (e)

    From the estimated pseudonormals, estimate the albedos and normals

    Parameters
    ----------
    B : numpy.ndarray
        The 3 x P matrix of estimated pseudonormals

    Returns
    -------
    albedos : numpy.ndarray
        The vector of albedos

    normals : numpy.ndarray
        The 3 x P matrix of normals
    '''

    albedos = None
    normals = None
    N = B.T
    albedos = np.zeros((N.shape[0]))
    for i in range(N.shape[0]):
        albedos[i] = np.sqrt(np.square(N[i][0]) + np.square(N[i][1]) + np.square(N[i][2]))

    normals = np.zeros((N.shape))
    for i in range(N.shape[0]):
        norm = np.sqrt(np.square(N[i][0]) + np.square(N[i][1]) + np.square(N[i][2]))
        normals[i] = N[i]/norm
    

    return albedos, normals.T


def displayAlbedosNormals(albedos, normals, s):

    """
    Question 1 (f)

    From the estimated pseudonormals, display the albedo and normal maps

    Please make sure to use the `coolwarm` colormap for the albedo image
    and the `rainbow` colormap for the normals.

    Parameters
    ----------
    albedos : numpy.ndarray
        The vector of albedos

    normals : numpy.ndarray
        The 3 x P matrix of normals

    s : tuple
        Image shape

    Returns
    -------
    albedoIm : numpy.ndarray
        Albedo image of shape s

    normalIm : numpy.ndarray
        Normals reshaped as an s x 3 image

    """

    albedoIm = None
    normalIm = None

    albedoIm = albedos.reshape(s[0],s[1])
    normals = normals.T
    normalIm = normals.reshape(s[0],s[1],3)

    fig, ax = plt.subplots(1,2, figsize=(20, 5),dpi=100)
    fig.suptitle('Albedo and Normal Images')

    ax[0].imshow(albedoIm,cmap='gray')
    ax[0].set_title('Albedo Image')

    ax[1].imshow(normalIm,cmap='rainbow')
    ax[1].set_title('Normal Image')

    #plt.savefig('albnorm2.png')

    plt.show()

    return albedoIm, normalIm


def estimateShape(normals, s):

    """
    Question 1 (i)

    Integrate the estimated normals to get an estimate of the depth map
    of the surface.

    Parameters
    ----------
    normals : numpy.ndarray
        The 3 x P matrix of normals

    s : tuple
        Image shape

    Returns
    ----------
    surface: numpy.ndarray
        The image, of size s, of estimated depths at each point

    """
    norm = normals.T.reshape(s[0],s[1],3)
    zx = -norm[:,:,0]/norm[:,:,2]
    zy = -norm[:,:,1]/norm[:,:,2]

    surface = integrateFrankot(zx, zy, pad = 512)
    return surface


def plotSurface(surface):

    """
    Question 1 (i) 

    Plot the depth map as a surface

    Parameters
    ----------
    surface : numpy.ndarray
        The depth map to be plotted

    Returns
    -------
        None

    """

    fig = plt.figure()
    ax = plt.axes(projection="3d")
    x =  np.arange(0,369)
    y = np.arange(0,431)

    X, Y = np.meshgrid(x, y)
    Z =surface
    ax = plt.axes(projection='3d')
    ax.plot_surface(X, Y, Z, rstride=1, cstride=1,cmap='coolwarm', edgecolor='none')
    ax.set_title('Surface')
    plt.savefig('surface_new.png')
    plt.show()


if __name__ == '__main__':

    # Put your main code here
    #pass
    res = np.array([3840,2160])
    center = np.array([0,0,0]) 
    rad = 0.45
    pxSize = 7
    light1 =  np.array([1/np.sqrt(3),1/np.sqrt(3),1/np.sqrt(3)]).reshape(1,-1)
    light2 =  np.array([1/np.sqrt(3),-1/np.sqrt(3),1/np.sqrt(3)]).reshape(1,-1)
    light3 =  np.array([-1/np.sqrt(3),-1/np.sqrt(3),1/np.sqrt(3)]).reshape(1,-1)

    l = []
    l = l + list(light1) + list(light2) + list(light3)
 
    for i in range(3):
    	image = renderNDotLSphere(center, rad, l[i], pxSize, res)

    I,L,s = loadData(path = "../data/")
    B = estimatePseudonormalsCalibrated(I, L)
    albedos,normals = estimateAlbedosNormals(B)
    albedoIm,normalIm = displayAlbedosNormals(albedos, normals, s)
    surface = estimateShape(normals, s)
    plotSurface(surface)
